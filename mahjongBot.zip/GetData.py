import json


def get_data():
    input_str = input()
    try:
        full_input = json.loads(input_str)
    except Exception as err:
        return input_str

    all_requests = full_input["requests"]

    curr_input = all_requests[-1]
    return curr_input
